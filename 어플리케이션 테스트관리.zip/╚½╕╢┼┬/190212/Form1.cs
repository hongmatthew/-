﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

// mysql 사용시 프로젝트의 참조에서 우클릭 참조추가에서 추가를 해야 using에서 추가 가능하다


namespace _190212
{
    public partial class Form1 : Form
    {
        Form1 f1;
        SqlConnection conn;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //msSql = new DB();
            //boardForm = new Board(msSql.Connection());

            //boardForm.Show();

            리스트();
        }

        public SqlConnection getConn()
        {
            return conn;
        }

        public SqlConnection Connection()
        {
            string host = "(localdb)\\ProjectsV13";
            string user = "root";
            string password = "1234";
            string db = "test2";

            string connStr = string.Format("server={0};uid={1};password={2};database={3}", host, user, password, db);
            SqlConnection conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                MessageBox.Show("MS-SQL 연결 성공!");
            }
            catch
            {
                conn.Close();
                MessageBox.Show("MS-SQL 연결 실패!");
            }

            return conn;
        }

        public bool Close()
        {
            try
            {
                conn.Close();
                MessageBox.Show("MS-SQL 연결끊기 성공!");
            }
            catch
            {
                MessageBox.Show("MS-SQL 연결끊기 실패!");
                return false;
            }

            return true;
        }

        public SqlDataReader Select(SqlConnection conn, string sql)
        {
            SqlCommand comm = new SqlCommand(sql, conn);
            SqlDataReader reader = comm.ExecuteReader();
            return reader;
        }

        public void SelectClose(SqlDataReader reader)
        {
            reader.Close();
        }

        public bool Insert(SqlConnection conn, string sql)
        {
            try
            {
                SqlCommand comm = new SqlCommand(sql, conn);
                comm.ExecuteNonQuery();
            }
            catch
            {
                return false;
            }

            return true;
        }




        private void 리스트()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";

            //tb1.Enabled = true;
            //tb4.Enabled = true;

            string sql = "select boardNo, boardTitle, boardContents, delYn from board;";
            SqlDataReader sdr = f1.Select(conn, sql);

            listView1.Clear();
            listView1.Columns.Add("번호", 50);
            listView1.Columns.Add("제목", 100);
            listView1.Columns.Add("내용", 250);
            listView1.Columns.Add("삭제여부", 90);
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                listView1.Items.Add(new ListViewItem(arr));
            }
            f1.SelectClose(sdr);
        }

        private void Btn1_Click(object sender, EventArgs e) // 추가
        {
            /*
            if (tb1.Text == "")
            {
                MessageBox.Show("번호를 입력하세요.");
                return;
            }
            */
            if (textBox1.Text == "")
            {
                MessageBox.Show("ID를 입력하세요.");
                return;
            }
            if (textBox2.Text == "")
            {
                MessageBox.Show("비밀번호를 입력하세요.");
                return;
            }
            string sql = string.Format("insert into board (eID, ePass) values ('{0}', '{1}');", textBox2.Text, textBox3.Text);
            //MessageBox.Show(sql);
            bool check = f1.Insert(conn, sql);
            if (check)
            {
                MessageBox.Show("저장을 성공하셨습니다.");
            }
            else
            {
                MessageBox.Show("저장 중 오류가 발생하였습니다.");
            }

            리스트();
        }

        private void Btn2_Click(object sender, EventArgs e) // 수정
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("제목을 입력하세요.");
                return;
            }
            if (textBox2.Text == "")
            {
                MessageBox.Show("내용을 입력하세요.");
                return;
            }
            string sql = string.Format("update board set eID = '{1}', ePass = '{2}' where delYn = {0};", textBox1.Text, textBox2.Text, textBox3.Text);
            bool check = f1.Insert(conn, sql);
            if (check)
            {
                MessageBox.Show("수정이 성공하셨습니다.");
            }
            else
            {
                MessageBox.Show("수정 중 오류가 발생하였습니다.");
            }

            리스트();
        }

        private void Btn3_Click(object sender, EventArgs e) // 삭제
        {
            string sql = string.Format("update board set delYn = 'Y' where boardNo = {0};", textBox1.Text);
            bool check = f1.Insert(conn, sql);
            if (check)
            {
                MessageBox.Show("삭제가 성공하셨습니다.");
            }
            else
            {
                MessageBox.Show("삭제 중 오류가 발생하였습니다.");
            }

            리스트();
        }

        private void Btn4_Click(object sender, EventArgs e) // 초기화
        {
            리스트();
        }

        private void Lv_MouseClick(object sender, MouseEventArgs e)
        {
            ListView lv = (ListView)sender;
            ListView.SelectedListViewItemCollection itemGroup = lv.SelectedItems;
            ListViewItem item = itemGroup[0];
            MessageBox.Show(item.SubItems[1].Text);

            string boardNo = item.SubItems[0].Text;
            string boardTitle = item.SubItems[1].Text;
            string boardContents = item.SubItems[2].Text;
            string delYn = item.SubItems[3].Text;

            textBox1.Text = boardNo;
            textBox2.Text = boardTitle;
           

            //tb1.Enabled = false;
            //tb4.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
