﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Test;

namespace WindowsFormsApp
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            Load += Form3_Load;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            if (FormLoad.GetLoad(this, "SDI"))
            {
                Database db = new Database(DataBaseInfo.TestDBInfo());
                Hashtable resultMap = db.GetReader("select rNo, rName, rDesc from [Rule];");
                if (Convert.ToInt32(resultMap["MsgCode"]) == -1)
                {
                    MessageBox.Show(resultMap["Msg"].ToString());
                }
                else
                {
                    ArrayList resultList = (ArrayList)resultMap["Data"];
                    foreach (string[] row in resultList)
                    {
                        listView1.Items.Add(new ListViewItem(new string[] { row[0], row[1], row[2] }));
                    }
                }
            }
        }
    }
}
