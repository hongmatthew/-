﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Test;

namespace WindowsFormsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Database db = new Database(DataBaseInfo.TestDBInfo());
            Hashtable resultMap = db.GetReader("select rNo, rName, rDesc from [Rule];");
            if (Convert.ToInt32(resultMap["MsgCode"]) == -1)
            {
                MessageBox.Show(resultMap["Msg"].ToString());
            }
            else
            {
                ArrayList resultList = (ArrayList)resultMap["Data"];
                string result = "";
                foreach (string[] row in resultList)
                {
                    result += string.Format("rNo : {0}, rName : {1}, rDesc : {2}", row[0], row[1], row[2]);
                }
                MessageBox.Show(result);
            }
        }
    }
}
