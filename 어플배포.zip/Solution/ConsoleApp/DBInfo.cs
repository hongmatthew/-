﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class DBInfo
    {
        public string server, uid, password, database;
        public DBInfo()
        {
            server = "(localdb)\\ProjectsV13";
            uid = "root";
            password = "1234";
            database = "Test";
        }
        public Hashtable GetDB()
        {
            Hashtable db = new Hashtable();
            db.Add("server", server);
            db.Add("uid", uid);
            db.Add("password", password);
            db.Add("database", database);
            return db;
        }
    }
}
