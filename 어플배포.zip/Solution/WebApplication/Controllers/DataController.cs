﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Test;

namespace WebApplication.Controllers
{

    public class DataController : Controller
    {
        [Route("api/Select")]
        [HttpGet]
        public ArrayList Select()
        {
            ArrayList resultList = null;
            Database db = new Database(DataBaseInfo.RealDBInfo());
            Hashtable resultMap = db.GetReader("select rNo, rName, rDesc from [Rule];");
            if (Convert.ToInt32(resultMap["MsgCode"]) == -1)
            {
                Console.WriteLine(resultMap["Msg"].ToString());
            }
            else
            {
                resultList = (ArrayList)resultMap["Data"];
            }

            return resultList;
        }


    }
}
