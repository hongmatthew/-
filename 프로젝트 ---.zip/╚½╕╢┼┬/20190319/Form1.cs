﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20190319
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Load += Form1_Load;
        }
        public int it;
        ListView lv;
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox0.Enabled = false;

            button1.Click += Button_Click;
            button2.Click += Button_Click;
            button3.Click += Button_Click;
            //button4.Click += Button_Click;
            button5.Click += Button_Click;
            listView1.MouseClick += ListView1_MouseClick;

            select();
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            switch(btn.Name)
            {
                case "button1":
                    select();
                    break;
                case "button2":
                    insert();
                    select();
                    break;
                case "button3":
                    update();
                    select();
                    break;
                //case "button4":
                //    delete();
                //    select();
                //    break;
                case "button5":
                    MessageBox.Show("* 학생 성적표가 전부 삭제 됩니다. *");
                    delete2();
                    select();
                    break;
            }
        }
        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            ListView lv = (ListView)sender;
            ListView.SelectedListViewItemCollection slvc = lv.SelectedItems;
            ListViewItem lvit = slvc[0];

           // MessageBox.Show(lvit.SubItems[0].Text);//텍스트의 넣는 값(문자)

            string no = lvit.SubItems[0].Text;
            string name = lvit.SubItems[1].Text;
            string 국어 = lvit.SubItems[2].Text;
            string 영어 = lvit.SubItems[3].Text;
            string 수학 = lvit.SubItems[4].Text;
            string 과학 = lvit.SubItems[5].Text;
            string 체육 = lvit.SubItems[6].Text;
            string 디자인 = lvit.SubItems[7].Text;
            string 회계 = lvit.SubItems[8].Text;
            string 컴공 = lvit.SubItems[9].Text;

            textBox0.Text = no;
            textBox1.Text = name;
            textBox2.Text = 국어;
            textBox3.Text = 영어;
            textBox4.Text = 수학;
            textBox5.Text = 과학;
            textBox6.Text = 체육;
            textBox7.Text = 디자인;
            textBox8.Text = 회계;
            textBox9.Text = 컴공;
        }

        private void select()
        {
                         
            string sql = "SELECT A.*,DENSE_RANK() OVER(ORDER BY A.평균 DESC) AS 등수 FROM(select no, name,국어, 영어, 수학, 과학, 체육, 디자인, 회계, 컴공, (국어 + 영어 + 수학 + 과학 + 체육 + 디자인 + 회계 + 컴공) / 8 as 평균 from test0319_school )A order by no; ";

            sqlreder(sql);
//            "select 국어,영어,수학,과학,체육,디자인,회계,컴공,(국어+영어+수학+과학+체육+디자인+회계+컴공)/8 as 평균 from test0319_school order by no";
        }
        public void insert()
        {
            // Array ar = new Array[]; 
            ArrayList al = new ArrayList();
            for(int i=1; i<al.Count;i++)
            {
                
            }
            //listView1.;
            TBText();
                int no = listView1.Items.Count + 1; // 6
            //textBox0.Text = no.ToString();
            string sql = string.Format("insert into test0319_school VAlues({0},'{1}',{2},{3},{4},{5},{6},{7},{8},{9},'','');", no, textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, textBox6.Text, textBox7.Text, textBox8.Text, textBox9.Text);
                sqlNon(sql);
            TBNoTest();
           
        }
        private void update()
        {
            TBText();
            string sql = string.Format("update test0319_school set 국어 = {0},영어={1},수학={2},과학={3},체육={4},디자인={5},회계={6},컴공={7} where  no='{8}';", textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, textBox6.Text, textBox7.Text, textBox8.Text, textBox9.Text, textBox0.Text);
            sqlNon(sql);
            TBNoTest();
        }
        private void delete()
        {   
            string sql =string.Format( "delete test0319_school where name ='{0}'",textBox0.Text);
            sqlNon(sql);
        }
        private void delete2()
        {
            string sql = string.Format("delete test0319_school ");
            sqlNon(sql);
        }


        private void sqlreder(string sql)
        {
            SqlConnection scon = new SqlConnection();
            scon.ConnectionString = @"Data Source=(localdb)\ProjectsV13; Initial Catalog =TEst3";
            try
            {
                scon.Open();
                //MessageBox.Show("연결");
                SqlCommand scom = new SqlCommand();
                scom.CommandText = sql;
                scom.Connection = scon;
                SqlDataReader sdr =scom.ExecuteReader();
                listView1.Items.Clear();
                while(sdr.Read())
                {
                    string[] str = new string[sdr.FieldCount];
                    for(int i=0; i<sdr.FieldCount;i++)
                    {
                        str[i] += sdr.GetValue(i);
                    }
                    listView1.Items.Add(new ListViewItem(str));
                }
            }
            catch
            {
                MessageBox.Show("실패");
            }
        }
        private void sqlNon(string sql)
        {
            SqlConnection scon = new SqlConnection();
            scon.ConnectionString = @"Data Source=(localdb)\ProjectsV13; Initial Catalog =TEst3";
            try
            {
                scon.Open();
                //MessageBox.Show("연결");
                SqlCommand scom = new SqlCommand();
                scom.CommandText = sql;
                scom.Connection = scon;
                scom.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("실패");
            }
        }

        private void TBText()
        {
            /*
            if (textBox0.Text == "")
            {
                MessageBox.Show("번호를 입력해주세요");
                return;
            }
            *///NO
            if (textBox1.Text == "")
            {
                MessageBox.Show("이름 입력해주세요");
                return;
            }//이름
            if (textBox2.Text == "")//국어
            {
                MessageBox.Show("국어점수를 입력해주세요");
                return;
            }//국어
            if (textBox3.Text == "")//영어
            {
                MessageBox.Show("영어점수를 입력해주세요");
                return;
            }//영어
            if (textBox4.Text == "")
            {
                MessageBox.Show("수학점수를 입력해주세요");
                return;
            }//수학
            if (textBox5.Text == "")
            {
                MessageBox.Show("과학점수를 입력해주세요");
                return;
            }//과학
            if (textBox6.Text == "")
            {
                MessageBox.Show("체육점수를 입력해주세요");
                return;
            }//체육
            if (textBox7.Text == "")
            {
                MessageBox.Show("디자인점수를 입력해주세요");
                return;
            }//디자인
            if (textBox8.Text == "")
            {
                MessageBox.Show("회계점수를 입력해주세요");
                return;
            }//회계
            if (textBox9.Text == "")
            {
                MessageBox.Show("컴공점수를 입력해주세요");
                return;
            }//컴공
        }
        private void TBNoTest()
        {
            if (textBox0.Text != "")
            {
                textBox0.Text = "";

            }//NO
            if (textBox1.Text != "")
            {
                textBox1.Text = "";

            }//이름
            if (textBox2.Text != "")//국어
            {
                textBox2.Text = "";

            }//국어
            if (textBox3.Text != "")//영어
            {
                textBox3.Text = "";

            }//영어
            if (textBox4.Text != "")
            {
                textBox4.Text = "";

            }//수학
            if (textBox5.Text != "")
            {
                textBox5.Text = "";

            }//과학
            if (textBox6.Text != "")
            {
                textBox6.Text = "";
            }//체육
            if (textBox7.Text != "")
            {
                textBox7.Text = "";
            }//디자인
            if (textBox8.Text != "")
            {
                textBox8.Text = "";
            }//회계
            if (textBox9.Text != "")
            {
                textBox9.Text = "";
            }//컴공
        }

      
    }
}
